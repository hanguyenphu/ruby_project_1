module CuisinesHelper
end
