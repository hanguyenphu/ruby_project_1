# frozen_string_literal: true

require 'pagy/extras/bootstrap'
