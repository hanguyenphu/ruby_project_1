require 'test_helper'

class ReviewerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
